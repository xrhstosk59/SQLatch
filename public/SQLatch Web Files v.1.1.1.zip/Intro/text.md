Η SQLatch είναι ένα καινοτόμο εργαλείο προγραμματισμού που σχεδιάστηκε για να διευκολύνει την εκμάθηση και τη χρήση της
γλώσσας SQL μέσω ενός απλού και ευδιάκριτου γραφικού περιβάλλοντος.

- Επιτρέπει την εύκολη σύνδεση block, όπως στο Scratch😺!


![using a color picker](Intro/easy.gif)

- Παρέχει μία μεγάλη πληθώρα εντολών


![using a color picker](Intro/toolbox.gif)

- Έχει έτοιμους οδηγούς με σενάρια και ασκήσεις


![using a color picker](Intro/guide.gif)

- Κάθε επερώτηση SQL απεικονίζεται με γραφικό τρόπο


![using a color picker](Intro/output.gif)
