## ΦΥΛΛΟ ΕΡΓΑΣΙΑΣ 1
1. Δημιουργήστε έναν πίνακα με το όνομα <span style="color:aquamarine">Φοιτητές</span> που θα περιέχει:
- Τον αριθμό μητρώου του Φοιτητή (<span style="color:aquamarine">ΑΜ</span>) το οποίο θα είναι το πρωτεύων κλειδί
- Το όνομα του φοιτητή (<span style="color:aquamarine">Όνομα</span>)
- Το επίθετο του φοιτητή (<span style="color:aquamarine">Επώνυμο</span>)
- Την ημερομηνία γέννησης του φοιτητή (<span style="color:aquamarine">ΗμερομηνίαΓέννησης</span>)

<details>
  <summary>Δείξε την λύση</summary>
  ![Screenshot](MDGuides/Tasks/Tasks1/images/first.png)
</details>

___
2. Δημιουργήστε έναν πίνακα με το όνομα <span style="color:aquamarine">Μαθήματα</span> που θα περιέχει:
- Τον κωδικό του μαθήματος (<span style="color:aquamarine">Κωδικός</span>) το οποίο θα είναι το πρωτεύων κλειδί 
- Το όνομα του μαθήματος (<span style="color:aquamarine">ΌνομαΜαθήματος</span>) 
- Το εξάμηνο στο οποίο διδάσκεται το μάθημα (<span style="color:aquamarine">Εξάμηνο</span>)


<details>
  <summary>Δείξε την λύση</summary>
  ![Screenshot](MDGuides/Tasks/Tasks1/images/second.png)
</details>

___
3. Δημιουργήστε έναν πίνακα με το όνομα <span style="color:aquamarine">Εγγραφές</span> όπου κάθε φοιτητής μπορεί να κάνει εγγραφή σε πολλά μαθήματα και θα περιέχει:
- Τον Αριθμό Μητρώου των φοιτητών που εγγράφονται σε μάθημα (<span style="color:aquamarine">ΑΜ</span>) 
- Τον κωδικό του μαθήματος εγγραφής (<span style="color:aquamarine">ΚωδικόςΜαθήματος</span>)
- Το πρωτεύων κλειδί του πίνακα αυτόυ θα είναι ο συνδιασμός των δύο στηλών του οι οποίες θα αποτελούν ταυτόχρονα ξένο κλειδί στον πίνακα Εγγραφές, η κάθε μία από τον πίνακα προέλευσής της


<details>
  <summary>Δείξε την λύση</summary>
  ![Screenshot](MDGuides/Tasks/Tasks1/images/third.png)

</details>

___
4. Στην συνέχεια εισάγετε στον κάθε πίνακα **3 εγγραφές** της επιλογής σας.

<details>
  <summary>Δείξε την λύση (παράδειγμα)</summary>
  ![Screenshot](MDGuides/Tasks/Tasks1/images/fourth.png)
</details>

___
