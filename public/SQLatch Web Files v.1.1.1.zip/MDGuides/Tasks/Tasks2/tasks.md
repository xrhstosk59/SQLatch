## ΦΥΛΛΟ ΕΡΓΑΣΙΑΣ 2
1. Εμφανίστε όλες τις πληροφορίες από τον πίνακα Φοιτητές

<details>
  <summary>Δείξε την λύση</summary>
  ![Screenshot](MDGuides/Tasks/Tasks2/images/first.png)
</details>

___
2. Εμφανίστε τα μαθήματα που διδάσκονται στο 1ο εξάμηνο

<details>
  <summary>Δείξε την λύση</summary>
  ![Screenshot](MDGuides/Tasks/Tasks2/images/second.png)
</details>

___
3. Εμφάνισε τα ΑΜ των φοιτητών που είναι εγγεγραμμένοι σε μαθήματα

<details>
  <summary>Δείξε την λύση</summary>
  ![Screenshot](MDGuides/Tasks/Tasks2/images/third.png)
</details>

___
4. Εμφάνισε τα μαθήματα που ο κωδικός τους είναι μεγαλύτερος του 1 ΚΑΙ το εξάμηνο διδασκαλίας τους μεγαλύτερο του πρώτου εξαμήνου

<details>
  <summary>Δείξε την λύση</summary>
  ![Screenshot](MDGuides/Tasks/Tasks2/images/fourth.png)
</details>
___
5. Ταξινόμησε την λίστα των Φοιτητών με φθίνουσα σειρά Αριθμού Μητρώου

<details>
  <summary>Δείξε την λύση</summary>
  ![Screenshot](MDGuides/Tasks/Tasks2/images/fifth.png)
</details>

___
6. Άλλαξε το όνομα του δεύτερου μαθήματος στον πίνακα των μαθημάτων με ένα όνομα της επιλογής σου

<details>
  <summary>Δείξε την λύση</summary>
  ![Screenshot](MDGuides/Tasks/Tasks2/images/sixth.png)
</details>

___
7. Διέγραψε έναν φοιτητή της επιλογής σου από όλα τα πεδία στα οποία είναι εγγεγραμμένος

<details>
  <summary>Δείξε την λύση</summary>
  ![Screenshot](MDGuides/Tasks/Tasks2/images/seventh.png)
</details>

___